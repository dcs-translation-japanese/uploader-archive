DCS World「ノースアメリカン TF-51D」トレーニング 日本語音声字幕 Ver1.00


■はじめに
・本MODは非公式の改造データのため、導入は自己責任でお願いします。
・本MODを導入したことによるデータの損失、その他あらゆる不具合、不都合が生じた場合についても、一切の責任を負いかねます。


■作業の流れ
①lang.cfgファイルを編集
②○○○.mizファイルを編集
③lessons.luaファイルを上書き保存


■注意事項
・ファイルを編集する前には、必ずバックアップを取るようにしましょう。
・元の英語解説文と異なる翻訳箇所があります。予めご了承ください。
・本MODの無断転載及び無断商用利用、無断配布行為は禁止です。


■インストール方法

①lang.cfgファイルを編集

lang.cfgをテキストエディタソフトなどで開き、EN から JP へ書き換えて保存します。

ファイルの場所は「C:\Program Files\Eagle Dynamics\DCS\Config\lang.cfg」です。

※デフォルトのインストール先になります。各自の設定環境(安定版、Open Beta版、STEAM版)で異なります。


②○○○.mizファイルを編集

Trainingフォルダ内の1～6_○○○_TF51.mizを解凍ソフトなどで開き、本MODデータ「l10n」フォルダをドラッグ＆ドロップして上書き保存します。

ファイルの場所は「C:\ProgramFiles\Eagle Dynamics\DCS\Mods\aircraft\TF-51D\Missions\Training」です。


③lessons.luaファイルを上書き保存

Trainingフォルダ内にあるlessons.luaファイルを本MODデータに上書き保存します。


最後に、ゲームを起動してフリーズなどのエラーが出ずに、日本語字幕と日本語音声が流れたら成功です。


■Q&A
Q1.翻訳が間違っている。
A.修正箇所がありましたら、twitter(@n4A2H2Gn2S6AcaE)にてご報告をお願いします。 
※音声も修正することになるので時間がかかります。

Q2.ゲームにバグがある(フラップレバーや操縦桿のロックなど)。
A.DCS公式フォーラムでユーザーからバグ報告が上がっているので、修正待ちになります。しかし、バグ修正の優先順位が低く時期は未定です。

Q3.ゲームオプション内の各設定項目(キーバインドなど)が日本語化されていない。
A.本MODはトレーニングミッション内容のみ日本語化となります。申し訳ありませんが、各自で日本語化をお願いします。


■謝辞
日本語化作業で利用しましたソフトウェア、ツール、参考サイトは下記の通りです。

DeepL翻訳
https://www.deepl.com/ja/translator

株式会社AHS「VOICEPEAK 商用可能 6ナレーターセット」
https://www.ah-soft.com/voice/6nare/

DCS World 日本語化ファイルアップローダー より、DCS翻訳サポート1.16　人柱バージョン
https://ux.getuploader.com/DCSJP1/download/221

mocchee様 DCS World 日本語化まとめ
https://www.mocchee.com/entry/dcs-japanese-menu

この場をお借りして感謝申し上げます。


■更新履歴
2022年3月13日　Ver1.00を公開