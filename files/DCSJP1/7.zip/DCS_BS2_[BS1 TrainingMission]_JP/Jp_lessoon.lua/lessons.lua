lessons = 
{
	{
        ["file"] = "",
        ["name"] = _("【BS1 LEGACY TRAINING MISSIONS】"),
        ["description"] = _(" オリジナルのKA-50 Black Sharkスタンドアロンモジュール(DCS Black Shark 1.0.2)用のEagle Dynamicsによってリリースされた英語のボイスオーバーによる22のトレーニングミッションです。\n\n カメラのビューと これらのミッションの詳細な性質は間違いなくあなたがKA-50をマスターするのに役立ちます。 \n\n ミッションがDCS Worldバージョンに含まれていなかったのでそれらを復活させることにしました。\n\n 全てのコンテンツはEagle Dynamicsによって作成されました。\n\n お楽しみください。\n\n "),
    },
	{
        ["file"] = "",
        ["name"] = _(""),
        ["description"] = _(""),
    },
	{
        ["file"] = "lesson_01_eng.miz",
        ["name"] = _("Module 1: KA-50 Black Shark の紹介"),
        ["description"] = _(" Ka-50 Black Shark 単座コクピット、同軸反転ローター combat helicopter."),
    },
	{
        ["file"] = "lesson_02_eng.miz",
        ["name"] = _("Module 2: コクピットシステム"),
        ["description"] = _(" KA-50のコックピットパネル、スイッチ、計測器、ゲージについて解説します。"),
    },
	{
        ["file"] = "lesson_03_eng.miz",
        ["name"] = _("Module 3: コミュニケーションシステム概要"),
        ["description"] = _(" 航空管制（ATC）及び地上要員と通信する方法を解説します。"),
    },
	{
        ["file"] = "lesson_04_eng.miz",
        ["name"] = _("Module 4: 高速始動方法"),
        ["description"] = _(" KA-50の高速始動方法を解説します。"),
    },
	{
        ["file"] = "lesson_05_eng.miz",
        ["name"] = _("Module 5: タキシング"),
        ["description"] = _(" タキシング手順を解説します。"),
    },
	{
        ["file"] = "lesson_06_eng.miz",
        ["name"] = _("Module 6: 停止方法"),
        ["description"] = _(" KA-50のエンジン停止方法を解説します。"),
    },
    {
        ["file"] = "lesson_07_eng.miz",
        ["name"] = _("Module 7: ホバリングコントロール"),
        ["description"] = _(" ホバリングコントロールの基礎を解説します。"),
    },
	{
        ["file"] = "lesson_08_eng.miz",
        ["name"] = _("Module 8: 垂直離陸"),
        ["description"] = _(" 垂直離陸を行う方法を解説します。"),
    },
	{
        ["file"] = "lesson_09_eng.miz",
        ["name"] = _("Module 9: 地面効果離陸"),
        ["description"] = _(" 地面効果を利用した離陸方法を解説します。"),
    },
	{
        ["file"] = "lesson_10_eng.miz",
        ["name"] = _("Module 10: ヘリコプター操縦機動"),
        ["description"] = _(" KA-50のマニューバについて解説します。"),
    },
	{
        ["file"] = "lesson_11_eng.miz",
        ["name"] = _("Module 11: 垂直着陸"),
        ["description"] = _(" エアクッション効果を利用し、KA-50を着陸させる方法を解説します。"),
    },
	{
        ["file"] = "lesson_12_eng.miz",
        ["name"] = _("Module 12: 滑走着陸"),
        ["description"] = _(" 気象条件・高度などで垂直着陸が難しい場合に行うローリング着陸について解説します。"),
    },
	{
        ["file"] = "lesson_13_eng.miz",
        ["name"] = _("Module 13: トラフィックパターンの飛行"),
        ["description"] = _(" トラフィックパターンでの飛行方法を解説します。"),
    },
	{
        ["file"] = "lesson_14_eng.miz",
        ["name"] = _("Module 14: ABRIS - 概要"),
        ["description"] = _(" K-50のナビゲーション装置であるABRISの主な操作モードと機能を解説します。"),
    },
	{
        ["file"] = "lesson_15_eng.miz",
        ["name"] = _("Module 15: ABRIS - 移動マップサブモード"),
        ["description"] = _(" ARBISのサブモードについて解説します。"),
    },
	{
        ["file"] = "lesson_16_eng.miz",
        ["name"] = _("Module 16: ABRIS - データリンク戦術情報"),
        ["description"] = _(" ARBISの戦術データリンクのシンボルを表示する機能について解説します。"),
    },
	{
        ["file"] = "lesson_17_eng.miz",
        ["name"] = _("Module 17: ABRIS - PLAN機能によるフライトプラン作成"),
        ["description"] = _(" ABRISでフライトプランを作成または編集する方法を解説します。"),
    },
	{
        ["file"] = "lesson_18_eng.miz",
        ["name"] = _("Module 18: 飛行ルート, PVI-800, オートパイロット"),
        ["description"] = _(" 航法システムに格納されたルートの飛行、また修正する方法を解説します。"),
    },
	{
        ["file"] = "lesson_19_eng.miz",
        ["name"] = _("Module 19: KA-50地上攻撃"),
        ["description"] = _(" KA-50の武装、地上攻撃方法を解説します。"),
    },
	{
        ["file"] = "lesson_20_eng.miz",
        ["name"] = _("Module 20: 僚機と外部ターゲティングシステム"),
        ["description"] = _(" 僚機に命令する方法と、編隊のメンバー内でデータリンクを用いて目標と航法のデータを送受信する方法を解説します。"),
    },
{
        ["file"] = "lesson_21_eng.miz",
        ["name"] = _("Module 21a: オートローテーションによる降下"),
        ["description"] = _(" エンジン故障発生時などのオートローテーションによる降下方法を解説します。"),
    },
{
        ["file"] = "lesson_22_eng.miz",
        ["name"] = _("Module 21b: オートローテーションによる着陸"),
        ["description"] = _(" オートローテーション時に安全に着陸する方法を解説します。"),
    },
	{
        ["file"] = "",
        ["name"] = _(""),
        ["description"] = _(""),
    },
	{
        ["file"] = "",
        ["name"] = _("【DCS WORLD TRAINING MISSIONS】"),
        ["description"] = _(""),
    },
	{
        ["file"] = "",
        ["name"] = _(""),
        ["description"] = _(""),
    },
{
        ["file"] = "BS2_Cold_Start_Training.miz",
        ["name"] = _("Aircraft Start-up - Step By Step"),
        ["description"] = _("In this lesson, we will practice starting the Ka-50 from the ramp."),
    },
	{
        ["file"] = "BS2_En-Route_Navigation_Training.miz",
        ["name"] = _("En-Route Navigation Training"),
        ["description"] = _("In this lesson, we will practice En-route navigation using the PVI-800, ABRIS and the autopilot."),
    },
	{
        ["file"] = "BS2_ABRIS_AMMS_Training.miz",
        ["name"] = _("ABRIS AMMS Overview"),
        ["description"] = _("In this lesson, we will review the ABRIS AMMS system of the KA-50."),
    },
	{
        ["file"] = "BS2_ABRIS_Advanced_Training.miz",
        ["name"] = _("ABRIS Advanced Training"),
        ["description"] = _("In this mission, you will learn about the various sub modes of the main operating modes of the ABRIS."),
    },
	{
        ["file"] = "BS2_Weapon Employment_Training.miz",
        ["name"] = _("Weapon Employment"),
        ["description"] = _("In this lesson, we will use the weapon systems."),
    },
	{
        ["file"] = "BS2_Countermeasure_training.miz",
        ["name"] = _("Counter measure training"),
        ["description"] = _("In this lesson, we will practice using the L-140 laser warning system, the UV-26 flare dispenser, and signal flare."),
    },
    {
        ["file"] = "BS2_Datalink_Wingmen_Training.miz",
        ["name"] = _("Datalink and Wingmen"),
        ["description"] = _("In this lesson you will learn to command your wingmen and issue targets through the data link."),
    },
} -- end of lessons
