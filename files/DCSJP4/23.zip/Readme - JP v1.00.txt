#######################################################################
#
# Oil In The Water - F/A-18C Campaign (SP & CO) Cold Start v2.9
# https://www.digitalcombatsimulator.com/en/files/3315461/
# 
# 　by BunnyClark
#
# Requirements:
#  - DCS: F/A-18C Hornet
#  - DCS: Supercarrier
#  - DCS: Persian Gulf
#
# ---------------------------------------------------------------------
# 日本語 翻訳 
#
#  by Kazupy
#
# 2024/09/01 v1.00 NEW
# 20xx/xx/xx v1.xx UPDATE
#
# :Nice campaign Thanks BunnyClark
#
#######################################################################

Eagle Dynamics社サイトのDownload User Files（https://www.digitalcombatsimulator.com/en/files/3315461/）にアップロードされている

『 Oil In The Water - F/A-18C Campaign (SP & CO) Cold Start v2.9 』

の日本語翻訳（基本DeepL翻訳 + 意訳）です。

ドライブ:\Users\[ Your Name ]\Saved Games\DCS\Missions\Campaigns\en\Oil In The Water CS\
配下の各ミッション.miz（圧縮）ファイル内の「\l10n」配下に、同じミッション名「\JP\dictionary」を追加してください。
（追加の方法や詳細は、各自の責任でご参照の上、実施をお願いします。）

■注意
※　ルートフォルダにある「Oil In The Water CS.cmp」ファイルは上書きになりますので気を付けてください。
※　すみません。机上でのチェックとある程度のプレイをしましたが、JP v1.00段階ではすべてをプレイテストができておりません。不具合や、ご意見あればお願いします。
※　SP and Cold Start版のみを翻訳しています。
