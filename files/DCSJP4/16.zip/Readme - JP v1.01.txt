#######################################################################
#
# F/A-18C Operation Black Knight [Singleplayer] v1.05
# https://www.digitalcombatsimulator.com/en/files/3325261/
# 
# 　by wildjager
#
# Requirements:
#  - DCS: F/A-18C Hornet
#  - DCS: Supercarrier
#
# Installation:
#  1- Unzip .rar file
#  2- Paste folder in "%user%Saved Games\DCS\Missions\Campaigns\En\"
#
# ---------------------------------------------------------------------
# 日本語 翻訳 
#
#  by Kazupy
#
# 2023/10/11 v1.00 NEW
# 2023/10/10 v1.01 UPDATE
#  - Mission 02 訳変更　大砲 → 迫撃砲陣地
#
# :Nice campaign Thanks wildjager
#
#######################################################################

Eagle Dynamics社サイトのDownload User Files（https://www.digitalcombatsimulator.com/en/files/）にアップロードされている

『 F/A-18C Operation Black Knight [Singleplayer] v1.05 』

の日本語翻訳（基本DeepL翻訳 + 意訳）です。
各ミッション毎に天候、時間が様々な上に、空対地、空対空、空対艦、それぞれの武装（REARM、REFUELも可）を使って
トレーニング的な感じの短時間ミッションが全23ミッションあり、

・Operation Black Knight
・Operation Black Shield
・Operation Black Spear
・Operation Lasting Peace

と、オペレーションが流れていく感じです。
基本的な作りでトリガー制御ガチガチでもなく、逆にそのため、クリアできないとか、クリア条件がわからないとか、AIが・・・とか、
もありますが、ミッションファイル単体をミッションエディタで変更も可能です。

■注意　
※全部のイベントを発生できているわけではないので、ご了承ください。
※ルートフォルダにある「Operation Black Knight.cmp」ファイルは上書きになりますので気を付けてください。

■参考
Eagle Dynamics社サイトからダウンロードしたキャンペーンファイルは、
「%user%Saved Games\DCS\Missions\Campaigns\Jp\」に保存しても、ゲーム内の「My Campaign」に標示されるようになります。
