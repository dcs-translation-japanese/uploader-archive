#######################################################################
#
# CAGE THE BEAR (Hornet mod v1.2.220520)
# https://www.digitalcombatsimulator.com/en/files/3308483/
# 
# 　by kabalum
#
# Requirements:
#  - DCS: F/A-18C Hornet
#  - DCS: Supercarrier
#
# ---------------------------------------------------------------------
# 日本語 翻訳 
#
#  by Kazupy
#
# 2024/08/18 v1.00 NEW
# 20xx/xx/xx v1.xx UPDATE
#
# :Nice campaign Thanks kabalum
#
#######################################################################

Eagle Dynamics社サイトのDownload User Files（https://www.digitalcombatsimulator.com/en/files/3308483/）にアップロードされている

『 OPERATION CAGE THE BEAR (HORNET MOD - SUPERCARRIER) by Kaba v1.21.28062020 』

の日本語翻訳（基本DeepL翻訳 + 意訳）です。

ドライブ:\Users\[ Your Name ]\Saved Games\DCS\Missions\Campaigns\en\CTB - HORNET\SUPERCARRIER\内の
各ミッション.miz（圧縮）ファイル内の「\l10n」配下に、同じミッション名「\JP\dictionary」を追加してください。
（追加の方法や詳細は、各自の責任でご参照の上実施ください。）

■注意
※ルートフォルダにある「FA-18C - Cage the bear - SUPERCARRIER v2.cmp」ファイルは上書きになりますので気を付けてください。
※全部のイベントを発生できているわけではないので、ご了承ください。
※SUPERCARRIER版のみを翻訳しています。
（もしかしたら、Non SUPERCARRIERも、翻訳は同じだとは思いますので適切なフォルダに移行すれば大丈夫だと思いますがテストをしていません。）
